package com.management.empcourse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpcourseApplication {

	public static void main(String[] args) {

		SpringApplication.run(EmpcourseApplication.class, args);

	}

}
