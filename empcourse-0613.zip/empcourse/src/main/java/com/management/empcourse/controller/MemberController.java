package com.management.empcourse.controller;

import com.management.empcourse.model.Member;
import com.management.empcourse.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.management.empcourse.controller.form.MemberForm;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.Map;

@Controller
public class MemberController {
    //private Object form;

//    @GetMapping("member/add")
    @RequestMapping("member/add")
    public String getAdd(MemberForm form,Model model) {
        model.addAttribute("memberForm",form);
        return "member/add";
    }
    @RequestMapping("member/manage")
    public String getList(MemberForm form,Model model) {
        model.addAttribute("memberForm",form);
        return "member/manage";
    }

    //@RequestMapping()

    @Autowired
    MemberService memberService;
    @GetMapping("member/search")
    public  String getSearch(@RequestParam Map<String,String> params, Model model){
        ArrayList<Member> members = memberService.selectMany(params);
        model.addAttribute("members",members);
        return "member/manage";
    }
}
