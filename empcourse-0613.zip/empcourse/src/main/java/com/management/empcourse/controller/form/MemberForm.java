package com.management.empcourse.controller.form;
import lombok.Data;

import com.management.empcourse.model.Member;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
public class MemberForm {

    private String empid;

    @Size(min=1, max=100)
    private String name;
    @NotNull
    private char sex;
    private String phonenum;
    @Size(min=1, max=100)
    private String address;
    @NotNull
    @Min(0)
    private Integer age;

    public MemberForm(){}

    public MemberForm(Member member){
        this.empid = member.getEmpid();
        this.name = member.getName();
        this.sex = member.getSex();
        this.age = member.getAge();
        this.phonenum = member.getPhonenum();
        this.address = member.getAddress();
    }
}
