package com.management.empcourse.model;

public class Score {
}
