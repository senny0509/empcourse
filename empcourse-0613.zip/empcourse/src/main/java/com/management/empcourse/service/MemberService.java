package com.management.empcourse.service;

import com.management.empcourse.model.Member;
import com.management.empcourse.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Map;

@Service
public class MemberService {

    @Autowired
    MemberRepository repository;

    public void save(Member member){

    }

    public boolean existsEmp(String empid){
        return repository.existsEmp(empid) == null ? false :true;
    }

    public ArrayList<Member> selectMany(Map<String,String> params){
        return repository.selectMany(params);
    }
}
