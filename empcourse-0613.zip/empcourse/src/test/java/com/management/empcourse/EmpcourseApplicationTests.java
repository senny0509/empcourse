package com.management.empcourse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpcourseApplicationTests {

	@Test
	void contextLoads() {
	}

}
