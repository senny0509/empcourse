package com.management.empcourse.controller.form;

import lombok.Data;

@Data
public class ScoreForm {

    private char empid;
    private char cid;
    private Integer sscore;
}
