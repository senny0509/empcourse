package com.management.empcourse.model;

import com.management.empcourse.controller.form.MemberForm;
import lombok.Data;
import org.apache.ibatis.annotations.Mapper;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
public class Member {
    public Member(){}

    public Member(MemberForm form){
        this.empid = form.getEmpid();
        this.name = form.getName();
        this.sex = form.getSex();
        this.age = form.getAge();
        this.phonenum = form.getPhonenum();
        this.address = form.getAddress();
    }

    private String empid;
    private String name;
    private char sex;
    private Integer age;
    private String phonenum;
    private String address;


}
