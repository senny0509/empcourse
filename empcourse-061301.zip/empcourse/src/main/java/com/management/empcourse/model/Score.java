package com.management.empcourse.model;

import com.management.empcourse.controller.form.ScoreForm;
import lombok.Data;

@Data
public class Score {
    public Score(){}

    public Score(ScoreForm form){
        //this.name = form.getName();
        //this.course = form.getCourse();
        this.empid = form.getEmpid();
        this.cid = form.getCid();
        this.sscore = form.getSscore();
    }

    //private String name;
    //private String course;
    private char empid;
    private char cid;
    private Integer sscore;
}
