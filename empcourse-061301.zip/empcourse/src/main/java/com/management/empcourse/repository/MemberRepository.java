package com.management.empcourse.repository;

import com.management.empcourse.model.Member;
import org.apache.ibatis.annotations.Mapper;

import java.util.ArrayList;
import java.util.Map;

@Mapper
public interface MemberRepository{
    public int save(Member member);
    public Member existsEmp(String empid);

    public ArrayList<Member> selectMany(Map<String, String> params);
    public Member selectOne(int empid);
}

