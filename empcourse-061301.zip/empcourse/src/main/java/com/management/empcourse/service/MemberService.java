package com.management.empcourse.service;

import com.management.empcourse.controller.form.MemberForm;
import com.management.empcourse.model.Member;
import com.management.empcourse.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Map;

@Service
public class MemberService {

    @Autowired
    MemberRepository repository;

    public void save(Member member){

    }

    public boolean existsEmp(String empid){
        return repository.existsEmp(empid) == null ? false :true;
    }

    public ArrayList<Member> selectMany(Map<String,String> params){
        return repository.selectMany(params);
    }

    public MemberForm selectOne(int empid){
        Member member = repository.selectOne(empid);
        if(member == null) throw new IllegalStateException("EmpID:" + empid + "の書籍情報は存在しません。");
        return new MemberForm(member);
    }
}
